import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router' // NEW: lets the app have pages with their own web addresses
import './index.css'
import App from './App.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter> {/* NEW: wraps the whole app so every page can use links */}
      <App />
    </BrowserRouter> {/* NEW */}
  </StrictMode>,
)
